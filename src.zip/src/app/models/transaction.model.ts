export interface Transaction {
    id: number;           // Unique identifier for the transaction
    accountId: number;    // ID of the account this transaction is associated with
    type: 'deposit' | 'withdrawal'; // Type of transaction (deposit or withdrawal)
    amount: number;       // Amount of money involved in the transaction
    date: string;         // Date of the transaction in ISO format (e.g., "2024-06-12")
  }
  