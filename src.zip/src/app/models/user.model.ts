export interface User {
    id: number;          // Unique identifier for the user
    name: string;        // User's full name
    email: string;       // User's email address
    password: string;    // Hashed password (do not store plain text password)
    role: 'user' | 'admin';  // User role (either "user" or "admin")
  }
  