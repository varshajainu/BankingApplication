export interface Account {
    id?: number;           // Unique identifier for the account
    userId?: number;       // User ID this account belongs to
    accountNumber: string; // The unique account number
    balance: number;      // Current balance in the account
  }
  