export interface Report {
    id: number;           // Unique identifier for the report
    reportType: string;   // Type of the report (e.g., "monthly_summary")
    dateGenerated: string; // Date when the report was generated (ISO format)
  }
  