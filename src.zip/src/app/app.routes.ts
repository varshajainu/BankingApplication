import { AdminLoginComponent } from './components/admin-login/admin-login.component';
import { Routes } from '@angular/router';
import { LoginComponent } from './components/authentication/login/login/login.component';
import { RegisterComponent } from './components/authentication/register/register/register.component';
import { LogoutComponent } from './components/authentication/logout/logout.component';
import { AccountCreationComponent } from './components/account/account-creation/account-creation.component';
import { AccountDashboardComponent } from './components/account/account-dashboard/account-dashboard.component';
import { AccountDetailsComponent } from './components/account/account-details/account-details.component';
import { TransactionDepositComponent } from './components/transactions/transaction-deposit/transaction-deposit.component';
import { TransactionHistoryComponent } from './components/transactions/transaction-history/transaction-history.component';
import { TransactionWithdrawComponent } from './components/transactions/transaction-withdraw/transaction-withdraw.component';
import { HomeComponent } from './components/home/home.component';
import { AdminComponent } from './components/admin/admin.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { SuccessComponent } from './components/success/success.component';
import { RouterModule } from '@angular/router';
// import { DashboardComponent } from './dashboard/dashboard.component'; // Import dashboard

export const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'home', component: HomeComponent },
  { path: 'loginadmin', component: AdminLoginComponent },
  { path: 'admin', component: AdminComponent },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'logout', component: LogoutComponent },

  // Success routes
  { path: 'success', component: SuccessComponent },

  // Account routes
  { path: 'account-dashboard', component: AccountDashboardComponent },
  { path: 'account-details', component: AccountDetailsComponent },
  { path: 'account-create', component: AccountCreationComponent },

  // Transaction routes
  { path: 'transaction-history', component: TransactionHistoryComponent },  // View transactions
  { path: 'deposit', component: TransactionDepositComponent },  // Deposit money
  { path: 'withdrawal', component: TransactionWithdrawComponent },  // Withdraw money

  // Default route to login
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  
];
