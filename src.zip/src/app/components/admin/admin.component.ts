import { Component, OnInit } from '@angular/core';
import { AdminService } from '../../services/admin.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  standalone:true,
  imports:[CommonModule,FormsModule],
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  users: any[] = [];
  accounts: any[] = [];
  reports: any[] = [];
  selectedSection: string = '';

  constructor(private adminService: AdminService) {}

  ngOnInit(): void {
    // Fetch data on component initialization
    this.adminService.getUsers().subscribe({
      next: (data) => {
        this.users = data;
      },
      error: (error) => {
        console.error('Error fetching users:', error);
      }
    });

    this.adminService.getAdmins().subscribe(data => {
      console.log(data);
    });
    
    this.adminService.getAccounts().subscribe({
      next: (data) => {
        this.accounts = data;
      },
      error: (error) => {
        console.error('Error fetching accounts:', error);
      }
    });

    this.adminService.getReports().subscribe({
      next: (data) => {
        this.reports = data;
      },
      error: (error) => {
        console.error('Error fetching reports:', error);
      }
    });
  }

  showUsers() {
    this.selectedSection = 'users';
  }

  showAccounts() {
    this.selectedSection = 'accounts';
  }

  showReports() {
    this.selectedSection = 'reports';
  }
}
