import { Component, OnInit } from '@angular/core';
import { AccountService } from '../../account/account.service';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Transaction } from '../../../models/transaction.model';// Import Transaction model
import { TransactionService } from '../../transactions/transaction.service';

@Component({
  selector: 'app-account-dashboard',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './account-dashboard.component.html',
  styleUrls: ['./account-dashboard.component.css'],
})
export class AccountDashboardComponent implements OnInit {
  accountDetails: any;
  transactions: Transaction[] = [];  // To hold transaction history
  errorMessage: string | null = null;
  depositForm: FormGroup;
  withdrawForm: FormGroup;

  constructor(
    private accountService: AccountService,
    private transactionService: TransactionService,
    private router: Router,
    private fb: FormBuilder
  ) {
    // Form initialization for deposit and withdrawal
    this.depositForm = this.fb.group({
      amount: ['', [Validators.required, Validators.min(1)]],
    });

    this.withdrawForm = this.fb.group({
      amount: ['', [Validators.required, Validators.min(1)]],
    });
  }

  ngOnInit(): void {
    const userId = localStorage.getItem('userId');
    if (!userId) {
      this.router.navigate(['/login']); // Redirect to login if not authenticated
      return;
    }
  
    this.accountService.getAccountByUserId(Number(userId)).subscribe(
      (account) => {
        if (account) {
          this.accountDetails = account;
          this.fetchTransactionHistory(account.id); // Pass the account ID
        } else {
          this.errorMessage = 'No account found for the logged-in user';
        }
      },
      (error) => {
        this.errorMessage = 'Error fetching account details';
      }
    );
  }
  
  // Fetch transactions for a specific account
  fetchTransactionHistory(accountId: number): void {
    this.accountService.getTransactionsByAccountId(accountId).subscribe(
      (data) => {
        this.transactions = data;
      },
      (error) => {
        this.errorMessage = 'Error fetching transaction history';
      }
    );
  }
  

  // Handle Deposit
 // In account-dashboard.component.ts
 onDeposit(): void {
  if (this.depositForm.invalid) return;
  const amount = this.depositForm.value.amount;

  this.accountService.deposit(amount, this.accountDetails.id).subscribe(
    (transaction) => {
      // Update balance on frontend
      this.accountDetails.balance += amount;

      // Persist the updated balance in the backend
      this.accountService.updateAccountBalance(this.accountDetails.id, this.accountDetails.balance).subscribe(
        () => {
          this.transactions.unshift(transaction); // Add transaction to the top
          this.depositForm.reset(); // Reset form
        },
        (error) => {
          this.errorMessage = 'Error updating balance';
        }
      );
    },
    (error) => {
      this.errorMessage = 'Error during deposit';
    }
  );
}

onWithdraw(): void {
  if (this.withdrawForm.invalid) return;
  const amount = this.withdrawForm.value.amount;

  if (amount > this.accountDetails.balance) {
    this.errorMessage = 'Insufficient balance';
    return;
  }

  this.accountService.withdraw(amount, this.accountDetails.id).subscribe(
    (transaction) => {
      // Update balance on frontend
      this.accountDetails.balance -= amount;

      // Persist the updated balance in the backend
      this.accountService.updateAccountBalance(this.accountDetails.id, this.accountDetails.balance).subscribe(
        () => {
          this.transactions.unshift(transaction); // Add transaction to the top
          this.withdrawForm.reset(); // Reset form
        },
        (error) => {
          this.errorMessage = 'Error updating balance';
        }
      );
    },
    (error) => {
      this.errorMessage = 'Error during withdrawal';
    }
  );
}


  // Navigate to Transaction History Page
  viewTransactionHistory(): void {
    this.router.navigate(['/transaction-history']); // You may also load the transaction history component inline if needed
  }
}
