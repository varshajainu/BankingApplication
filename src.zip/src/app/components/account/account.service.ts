// import { Injectable } from '@angular/core';
// import { HttpClient } from '@angular/common/http';
// import { Observable } from 'rxjs';
// import { Account } from '../models/account.model';
// import { Transaction } from '../models/transaction.model';  // Add this import for Transaction model

// @Injectable({
//   providedIn: 'root',
// })
// export class AccountService {
//   private apiUrl = 'http://localhost:3000/accounts'; // JSON Server endpoint
//   private transactionsUrl = 'http://localhost:3000/transactions'; // Endpoint for transactions

//   constructor(private http: HttpClient) {}

//   // Get account details
//   getAccountDetails(): Observable<Account> {
//     return this.http.get<Account>(`${this.apiUrl}/1`); // Example for the first account
//   }

//   // Create a new account
//   createAccount(account: Omit<Account, 'id' | 'userId'>): Observable<Account> {
//     return this.http.post<Account>(this.apiUrl, account);
//   }

//   // Deposit money into account
//   deposit(amount: number, accountId: number): Observable<Transaction> {
//     const transaction: Transaction = {
//       id: Math.floor(Math.random() * 1000), // Unique ID, can be handled differently in a real app
//       accountId,
//       type: 'deposit',
//       amount,
//       date: new Date().toISOString(),
//     };

//     // Update the account balance (assuming you are adding the amount to current balance)
//     return this.http.post<Transaction>(this.transactionsUrl, transaction);
//   }

//   // Withdraw money from account
//   withdraw(amount: number, accountId: number): Observable<Transaction> {
//     const transaction: Transaction = {
//       id: Math.floor(Math.random() * 1000), // Unique ID
//       accountId,
//       type: 'withdrawal',
//       amount,
//       date: new Date().toISOString(),
//     };

//     // Update the account balance (assuming you are deducting the amount from current balance)
//     return this.http.post<Transaction>(this.transactionsUrl, transaction);
//   }

//   // Get transaction history for an account
//   getTransactionHistory(accountId: number): Observable<Transaction[]> {
//     return this.http.get<Transaction[]>(`${this.transactionsUrl}?accountId=${accountId}`);
//   }
// }
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map, Observable, switchMap } from 'rxjs';
import { Account } from '../../models/account.model';
import { Transaction } from '../../models/transaction.model';

@Injectable({
  providedIn: 'root',
})
export class AccountService {
  private apiUrl = 'http://localhost:3000/accounts'; // JSON Server endpoint
  private transactionsUrl = 'http://localhost:3000/transactions'; // Endpoint for transactions

  constructor(private http: HttpClient) {}

  // Get account details
  getAccountDetails(): Observable<Account> {
    return this.http.get<Account>(`${this.apiUrl}/1`); // Example for the first account
  }
  getAccountByUserId(userId: number): Observable<any> {
    return this.http.get<any[]>(`http://localhost:3000/accounts?userId=${userId}`).pipe(
      map((accounts) => (accounts.length > 0 ? accounts[0] : null))
    );
  }
  

  // Create a new account
 
  createAccount(accountData: { userId: number | null; accountNumber: string; balance: number }): Observable<any> {
    return this.http.post(this.apiUrl, accountData);
  }
  // Deposit money into account
  deposit(amount: number, accountId: number): Observable<Transaction> {
    const transaction: Transaction = {
      id: Math.floor(Math.random() * 1000), // Unique ID, can be handled differently in a real app
      accountId,
      type: 'deposit',
      amount,
      date: new Date().toISOString(),
    };

    // Update the account balance (assuming you are adding the amount to current balance)
    return this.http.post<Transaction>(this.transactionsUrl, transaction);
  }

  // Withdraw money from account
  withdraw(amount: number, accountId: number): Observable<Transaction> {
    const transaction: Transaction = {
      id: Math.floor(Math.random() * 1000), // Unique ID
      accountId,
      type: 'withdrawal',
      amount,
      date: new Date().toISOString(),
    };

    // Update the account balance (assuming you are deducting the amount from current balance)
    return this.http.post<Transaction>(this.transactionsUrl, transaction);
  }

  // Get transaction history for an account
  getTransactionHistory(accountId: number): Observable<Transaction[]> {
    return this.http.get<Transaction[]>(`${this.transactionsUrl}?accountId=${accountId}`);
  }
  
  updateAccountBalance(accountId: number, updatedBalance: number): Observable<any> {
    // Fetch the current account details
    return this.http.get<Account>(`${this.apiUrl}/${accountId}`).pipe(
      switchMap(account => {
        // Update the account balance while preserving other fields
        account.balance = updatedBalance;
  
        // Update the account with the new balance
        return this.http.put<Account>(`${this.apiUrl}/${accountId}`, account);
      })
    );
  }
 
  
  getTransactionsByAccountId(accountId: number): Observable<Transaction[]> {
    return this.http.get<Transaction[]>(`${this.apiUrl}?accountId=${accountId}`);
  }
  
  
}
