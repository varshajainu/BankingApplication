import { Component } from '@angular/core';
import { AccountService } from '../../account/account.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-account-details',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './account-details.component.html',
  styleUrls: ['./account-details.component.css']
})
export class AccountDetailsComponent {
  accountDetails: any;
  errorMessage: string | null = null;

  constructor(private accountService: AccountService) {}

  ngOnInit() {
    this.accountService.getAccountDetails().subscribe(
      (data) => {
        this.accountDetails = data;
      },
      (error) => {
        this.errorMessage = 'Error fetching account details';
      }
    );
  }
}
