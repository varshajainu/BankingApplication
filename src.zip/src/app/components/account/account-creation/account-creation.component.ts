import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AccountService } from '../../account/account.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-account-create',
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './account-creation.component.html',
  styleUrls: ['./account-creation.component.css'],
  standalone: true,
})
export class AccountCreationComponent {
  createForm: FormGroup;
  errorMessage: string | null = null;
  userId: number | null = null;

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private accountService: AccountService,
    private router: Router
  ) {
    this.createForm = this.fb.group({
      initialDeposit: ['', [Validators.required, Validators.min(100)]],
    });

    // Get userId from query parameters
    this.route.queryParams.subscribe((params) => {
      this.userId = params['userId'];
    });
  }

  onSubmit() {
    if (this.createForm.invalid) {
      this.errorMessage = 'Invalid form input.';
      return;
    }
  
    const accountData = {
      userId: this.userId,
      accountNumber: this.generateAccountNumber(),
      balance: this.createForm.value.initialDeposit,
    };
  
    console.log('Account data being sent:', accountData);
  
    this.accountService.createAccount(accountData).subscribe(
      (response) => {
        console.log('Account created successfully:', response);
        this.router.navigate(['/login']); // Navigate after success
      },
      (error) => {
        console.error('Error creating account:', error);
        this.errorMessage = 'Error creating account. Please try again.';
      }
    );
  }
  

  generateAccountNumber(): string {
    return Math.floor(100000000000 + Math.random() * 900000000000).toString();
  }
}
