import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AdminService } from '../../services/admin.service';

@Component({
  selector: 'app-admin-login',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './admin-login.component.html',
  styleUrl: './admin-login.component.css'
})
export class AdminLoginComponent {
  adminLoginForm: FormGroup;
  private readonly adminUsername = 'admin';
  private readonly adminPassword = 'admin123';

  constructor(private fb: FormBuilder, private router: Router) {
    this.adminLoginForm = this.fb.group({
      username: ['', [Validators.required]],
      password: ['', [Validators.required]]
    });
  }

  onAdminLogin() {
    const { username, password } = this.adminLoginForm.value;
    if (username === this.adminUsername && password === this.adminPassword) {
      this.router.navigate(['/admin']);
    } else {
      alert('Invalid admin credentials.');
    }
  }
}


