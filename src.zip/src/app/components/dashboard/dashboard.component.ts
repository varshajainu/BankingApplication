import { Component, OnInit } from '@angular/core';
import { UserService } from '../../services/user.service';
import { AccountService } from '../../services/account.service';
import { TransactionService } from '../../services/transaction.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  users: any[] = [];
  userDetails: any = {};
  accounts: any[] = [];
  transactions: any[] = [];

  constructor(
    private userService: UserService,
    private accountService: AccountService,
    private transactionService: TransactionService
  ) {}

  
  ngOnInit(): void {
    this.userService.getUserDetails().subscribe(data => this.userDetails = data);
    this.userService.getUserAccounts().subscribe(data => {
      this.accounts = data; // Assign the response to userAccounts
    });
    this.accountService.getAccounts().subscribe(data => this.accounts = data);
    this.transactionService.getTransactions().subscribe(data => this.transactions = data);
    this.fetchUserDetails();
    this.fetchAccounts();
  }
  fetchUserDetails() {
    this.userService.getLoggedInUser().subscribe({
      next: (data) => {
        this.users = data;
      },
      error: (error) => {
        console.error('Error fetching user details:', error);
      }
    });
  }

  fetchAccounts() {
    this.accountService.getAccounts().subscribe({
      next: (data) => {
        this.accounts = data;
      },
      error: (error) => {
        console.error('Error fetching accounts:', error);
      }
    });
  }

}
