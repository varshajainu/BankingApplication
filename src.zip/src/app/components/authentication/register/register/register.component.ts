import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { AuthService } from '../../../../services/auth.service';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { provideRouter, RouterModule } from '@angular/router';

@Component({
  selector: 'app-register',
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
  standalone: true
})
export class RegisterComponent {
  registerForm: FormGroup;
  errorMessage: string | null = null;
  successMessage: string | null = null;
  userExists: boolean = false;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) {
    this.registerForm = this.fb.group({
      name: ['', [Validators.required]],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', [Validators.required]],
      role: ['user']
    });
  }

  goToLogin(): void {
    this.router.navigate(['/login']);
  }
  
  onSubmit(): void {
    if (this.registerForm.invalid) return;

    const newUser =  {
      name: this.registerForm.value.name,
      email: this.registerForm.value.email,
      password: this.registerForm.value.password
    };
    
    console.log('Registering User:', newUser);
    
    // this.authService.register(newUser).subscribe(
    //   (user) => {
    //     if (user) {
    //       this.successMessage = 'User successfully registered! Redirecting...';
    //       this.errorMessage = null;
    //       this.userExists = false;

    //       setTimeout(() => {
    //         this.router.navigate(['/success']);
    //       }, 2000);
    //     }
    //   },
    //   (error) => {
    //     if (error.status === 409) {
    //       this.userExists = true;
    //       this.successMessage = null;
    //       this.errorMessage = 'User already exists. Please log in.';
    //     } else {
    //       this.userExists = false;
    //       this.successMessage = null;
    //       this.errorMessage = 'Failed to register. Please try again.';
    //     }
    //   }
    // );
    this.authService.register(newUser).subscribe(
      (response) => {
        console.log('Registration Success:', response);
        this.successMessage = 'User successfully registered! Redirecting...';
        this.errorMessage = null;
        
        setTimeout(() => {
          this.router.navigate(['/login']);
        }, 2000);
      },
      (error) => {
            if (error.status === 409) {
            this.userExists = true;
             this.successMessage = null;
              this.errorMessage = 'User already exists. Please log in.';
            } else {
              this.userExists = false;
               this.successMessage = null;
              this.errorMessage = 'Failed to register. Please try again.';
      
            }
          }
    );
  
  }
}