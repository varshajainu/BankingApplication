import { Component, OnInit } from '@angular/core';
import { LoginAttemptService } from '../../services/login_attempt.service';
@Component({
  selector: 'app-login-attempts',
  templateUrl: './login_attempts.component.html',
  styleUrls: ['./login_attempts.component.css']
})
export class LoginAttemptsComponent implements OnInit {
  loginAttempts: any[] = [];

  constructor(private loginAttemptService: LoginAttemptService) {}

  ngOnInit(): void {
    this.loginAttemptService.getLoginAttempts().subscribe({
      next: (data) => {
        this.loginAttempts = data;
      },
      error: (error) => {
        console.error('Error fetching login attempts:', error);
      }
    });
  }
}
