import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { TransactionService } from '../transaction.service'; // Transaction service to handle the API call
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-transaction-deposit',
  standalone:true,
  imports:[ReactiveFormsModule,CommonModule],
  templateUrl: './transaction-deposit.component.html',
  styleUrls: ['./transaction-deposit.component.css'],
})
export class TransactionDepositComponent {
  depositForm: FormGroup;
  errorMessage: string | null = null;

  constructor(
    private fb: FormBuilder,
    private transactionService: TransactionService,
    private router: Router
  ) {
    this.depositForm = this.fb.group({
      amount: ['', [Validators.required, Validators.min(1)]],
    });
  }

  onSubmit(): void {
    if (this.depositForm.invalid) return;

    const amount = this.depositForm.value.amount;
    const accountId = 1; // Assuming account ID is available or retrieved from a user session

    this.transactionService.createTransaction(accountId, 'deposit', amount).subscribe(
      (transaction) => {
        this.router.navigate(['/transaction-history']);
      },
      (error) => {
        this.errorMessage = 'Failed to make deposit. Please try again later.';
      }
    );
  }
}
