import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TransactionDepositComponent } from './transaction-deposit.component';

describe('TransactionDepositComponent', () => {
  let component: TransactionDepositComponent;
  let fixture: ComponentFixture<TransactionDepositComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TransactionDepositComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TransactionDepositComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
