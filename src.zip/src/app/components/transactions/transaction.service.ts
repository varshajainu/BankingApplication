import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Transaction } from '../../models/transaction.model'; // Assuming model is defined in models folder

@Injectable({
  providedIn: 'root',
})
export class TransactionService {
  private apiUrl = 'http://localhost:3000/transactions'; // Assuming backend API

  constructor(private http: HttpClient) {}

  // Create a new transaction (deposit or withdrawal)
  createTransaction(accountId: number, type: 'deposit' | 'withdrawal', amount: number): Observable<Transaction> {
    const transaction: Transaction = {
      id: Date.now(), // Using timestamp as a mock ID
      accountId: accountId,
      type: type,
      amount: amount,
      date: new Date().toISOString(),
    };
    return this.http.post<Transaction>(this.apiUrl, transaction);
  }

  // Get all transactions for an account
  getTransactions(): Observable<Transaction[]> {
    return this.http.get<Transaction[]>(this.apiUrl);
  }
}
