import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { TransactionService } from '../../transactions/transaction.service';
import { Transaction } from '../../../models/transaction.model';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-transaction-history',
  standalone:true,
  imports:[ReactiveFormsModule,CommonModule],
  templateUrl: './transaction-history.component.html',
  styleUrls: ['./transaction-history.component.css'],
})
export class TransactionHistoryComponent implements OnInit {
  transactions: Transaction[] = [];
  filteredTransactions: Transaction[] = [];
  filterForm: FormGroup;
  errorMessage: string | null = null;
  totalAmount: number | null = null;

  constructor(
    private transactionService: TransactionService,
    private fb: FormBuilder
  ) {
    this.filterForm = this.fb.group({
      type: [''],
      amount: [''],
      fromDate: [''],
      toDate: [''],
    });
  }

  ngOnInit(): void {
    this.fetchTransactionHistory();
  }

  fetchTransactionHistory(): void {
    // Fetch all transactions
    this.transactionService.getTransactions().subscribe(
      (data) => {
        this.transactions = data;
        this.filteredTransactions = [...this.transactions]; // Initially, no filter
      },
      (error) => {
        this.errorMessage = 'Error fetching transaction history';
      }
    );
  }

  // Apply filters to transactions
  applyFilters(): void {
    let filtered = [...this.transactions];

    // Filter by Type
    if (this.filterForm.value.type) {
      filtered = filtered.filter(
        (transaction) => transaction.type === this.filterForm.value.type
      );
    }

    // Filter by Amount
    if (this.filterForm.value.amount === 'greater') {
      filtered = filtered.filter((transaction) => transaction.amount > 1000);
    } else if (this.filterForm.value.amount === 'less') {
      filtered = filtered.filter((transaction) => transaction.amount < 1000);
    }

    // Filter by Date Range
    const fromDate = this.filterForm.value.fromDate
      ? new Date(this.filterForm.value.fromDate)
      : null;
    const toDate = this.filterForm.value.toDate
      ? new Date(this.filterForm.value.toDate)
      : null;

    if (fromDate) {
      filtered = filtered.filter(
        (transaction) => new Date(transaction.date) >= fromDate
      );
    }

    if (toDate) {
      filtered = filtered.filter(
        (transaction) => new Date(transaction.date) <= toDate
      );
    }

    // Update filtered transactions
    this.filteredTransactions = filtered;
  }

  // Calculate and show total sum of transactions
  viewTotal(): void {
    this.totalAmount = this.filteredTransactions.reduce(
      (sum, transaction) => sum + transaction.amount,
      0
    );
  }
}
