import { Component } from '@angular/core';

@Component({
  selector: 'app-transaction-transfer',
  standalone: true,
  imports: [],
  templateUrl: './transaction-transfer.component.html',
  styleUrl: './transaction-transfer.component.css'
})
export class TransactionTransferComponent {

}
