import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { TransactionService } from '../transaction.service'; // Transaction service to handle the API call
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-transaction-withdraw',
  standalone:true,
  imports:[ReactiveFormsModule,CommonModule],
  templateUrl: './transaction-withdraw.component.html',
  styleUrls: ['./transaction-withdraw.component.css'],
})
export class TransactionWithdrawComponent {
  withdrawForm: FormGroup;
  errorMessage: string | null = null;

  constructor(
    private fb: FormBuilder,
    private transactionService: TransactionService,
    private router: Router
  ) {
    this.withdrawForm = this.fb.group({
      amount: ['', [Validators.required, Validators.min(1)]],
    });
  }

  onSubmit(): void {
    if (this.withdrawForm.invalid) return;

    const amount = this.withdrawForm.value.amount;
    const accountId = 1; // Assuming account ID is available or retrieved from a user session

    this.transactionService.createTransaction(accountId, 'withdrawal', amount).subscribe(
      (transaction) => {
        this.router.navigate(['/transaction-history']);
      },
      (error) => {
        this.errorMessage = 'Failed to make withdrawal. Please try again later.';
      }
    );
  }
}
