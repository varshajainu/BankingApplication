import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  constructor(private router: Router,private http: HttpClient) {}

  // Simulated login method
  login(user: { email: string; password: string }): boolean {
    // Simulate authentication
    if (user.email === 'admin@example.com' && user.password === 'admin123') {
      localStorage.setItem('role', 'admin');
      localStorage.setItem('isLoggedIn', 'true');
      return true; // Login success
    } else if (user.email === 'user@example.com' && user.password === 'user123') {
      localStorage.setItem('role', 'user');
      localStorage.setItem('isLoggedIn', 'true');
      return true; // Login success
    } else {
      return false; // Login failed
    }
  }

  // Logout method
  logout(): void {
    localStorage.removeItem('role');
    localStorage.removeItem('isLoggedIn');
    this.router.navigate(['/']);
  }

  // Check if user is logged in
  isLoggedIn(): boolean {
    return localStorage.getItem('isLoggedIn') === 'true';
  }

  // Get user role
  getRole(): string | null {
    return localStorage.getItem('role');
  }
  private apiUrl = 'http://localhost:8080/api/users';

 

  getUsers(): Observable<any[]> {
    return this.http.get<any[]>(this.apiUrl);
  }

  addUser(user: any): Observable<any> {
    return this.http.post<any>(this.apiUrl, user);
  }

  findUser(username: string, password: string): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}?username=${username}&password=${password}`);
  }
  

  // 
  private currentUser: any = null;


  
  getCurrentUser() {
    return this.currentUser;
  }

}


