import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AuthService } from './services/auth.service';
import { ReactiveFormsModule } from '@angular/forms';
import { routes } from './app.routes';
import { RouterModule } from '@angular/router';
@NgModule({
  imports: [
    HttpClientModule, // Import HttpClient
    NgModule,
    FormsModule,
    routes,
    RouterModule,
    ReactiveFormsModule
  ],
  providers: [AuthService]
})
export class AppModule { }
