import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root',
})
export class AdminGuard implements CanActivate {
  constructor(private router: Router) {}

  // Simulated check for admin role
  canActivate(): boolean {
    // Retrieve the logged-in user role (this can be from localStorage, a service, or another method)
    const userRole = localStorage.getItem('role'); // Assuming role is stored in localStorage

    if (userRole === 'admin') {
      return true; // Allow access if user is an admin
    } else {
      this.router.navigate(['/user-login']); // Redirect to user login if not admin
      return false; // Deny access
    }
  }
  
  
}
