import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/internal/Observable';

@Injectable({ providedIn: 'root' })
export class LoginAttemptService {
  private apiUrl = 'http://localhost:8080/api/login-attempts';

  constructor(private http: HttpClient) {}

  getLoginAttempts(): Observable<any> {
    return this.http.get(`${this.apiUrl}`);
  }

  getLoginAttemptById(id: number): Observable<any> {
    return this.http.get(`${this.apiUrl}/${id}`);
  }
}