import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import { User } from '../models/user.model';
import { catchError, map } from 'rxjs/operators';
import { FormsModule } from '@angular/forms';
import { LoginComponent } from '../components/authentication/login/login/login.component';
@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private apiUrl = 'http://localhost:8080/api/users'; // JSON Server API for users
  private currentUserSubject: BehaviorSubject<User | null>;
  public currentUser: Observable<User | null>;

  constructor(private http: HttpClient) {
    const storedUser = localStorage.getItem('currentUser');
    this.currentUserSubject = new BehaviorSubject<User | null>(
      storedUser ? JSON.parse(storedUser) : null
    );
    this.currentUser = this.currentUserSubject.asObservable();
  }

  register(user: any): Observable<any> {
    return this.http.post<any>('http://localhost:8080/api/users/register', user);
  }
  
  // // Register a new user
  // register(user: User): Observable<User> {
  //   return this.http.post<User>(this.apiUrl, user);
  // }

  // Login user
  login(email: string, password: string): Observable<any> {
    return this.http.get<any[]>(`${this.apiUrl}?email=${email}&password=${password}`).pipe(
      map((users) => {
        if (users.length > 0) {
          const user = users[0];
          localStorage.setItem('isLoggedIn', 'true');
          localStorage.setItem('userId', user.id); // Store the user ID
          return user;
        } 
      })
    );
  }

  // Logout user
  logout(): void {
    // Clear user data from localStorage and BehaviorSubject
    localStorage.removeItem('currentUser');
    this.currentUserSubject.next(null);
  }

  // Check if the user is logged in
  isAuthenticated(): boolean {
    return !!this.currentUserSubject.value;
  }

  // Get the currently logged-in user
  getCurrentUser(): User | null {
    return this.currentUserSubject.value;
  }
}
